# ProsperLoanData Exploration
## by Bello Abdulkabir


## Dataset -- ProsperLoan Data

> This dataset consists of 113,937 loanee information with 81 variables. For the purpose of this exploration, not all varaibles come in handy so i used only the ones that i felt would bring out some intersting trends to note. Some transformation was done to the `EmploymentStatus` column and its initial datatype was altered. The dataset used for the purpose of this project can be found in the zipfile.


## Summary of Findings
- The highest distribution of loan amount falls around 10,000 15,000 and 4000 with the most reoccuring of them all being around the 4,000 mark.
- The servicing fee on most of the loan falls under the 0.010 percentage rate.
- Most loanees in our dataset are employed or working full-time.
- The interest rate follows a normal distribution with its highest peak between the 0.10 to 0.15 range. The annual percentage rate has its highest peak at 0.20. while, the Estimated returns has its highest peak between 0.7 to 0.9.
- The interest rate and annual percentage rate have a strong positive correlation between the Estimated return and Estimated loss, with a slight negative correlation with the loan original amount and monthly loan payment.
Also, the stated monthly income has a slight positive correlation with the original loan amount and the monthly loan payment. While, the monthly loan payment is directly proportional to the original loan amount.
- The number of investors sponsoring a loan is positively related to higher loan amounts.
- Loanees who are unemployed have a higher borrower rate followed by loanees who are self-employed.
- 90% of loanees who are home owners are employed or working full-time.
- loanees who are home owners borrow larger amounts than those who are not home owners.
- Longer loan duration attracts a higher interest rate and estimated return.
- There's no strong correlation between the laon status, loan amount and employment status. 


## Key Insights for Presentation
> Firstly i started off by displaying the distribution of the loan original price in our dataset so my viewers will have a clear insight on the amount of money most loanees requests for. I used smaller bins for easier readability.
Then, i moved on to check for relationship between the investors of a loan and the loan original price. Both the heatmap and scatterplot depicted in the slide shows us a positive trend between investors and loan amount.After reducing the opacity of the scatterplot,a log-scaling was used for the x-axis and i limited the y-axis to 300 so as to zoom into my data more and reduce overplotting. Asides the heatmap and scatterplot both showing us the postive tend, the heatmap also shows us the distribution of loanees based on the original loan amount issued to them.
Afterwards, i plotted a barplot to show the distribution of loan original price by home ownership and employment status. i used different colors to represent the status of the home ownership while the x-axis represented the employment satus of the loanees, with the y-axis representing original loan amount, and the small whiskers representing the mean of each bar. Through this visualisation i was able to see that the home-owners borrow larger amounts of money than their counterparts. also, those who are employed borrow the largest amounts while those who are retired borrow the least amounts in the entire dataset.
lastly, a multivariate scatterplot was plotted on loan term by interest rate and estimated returns. Unique color configuration was used to represent the different loan durations and through this approach we could see the distribution of loan periods as it follows the trend. The shorter loan periods attacted lesser interest rate as compared to the longer periods. 